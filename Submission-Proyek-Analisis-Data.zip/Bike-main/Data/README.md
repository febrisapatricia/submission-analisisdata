# 🚲 BIKERS : Bike-sharing Analysis Dashboard

## Setup environment
```
python -m venv dashboard
dashboard\Scripts\activate
pip install numpy pandas scipy matplotlib seaborn jupyter streamlit babel
```

## Run steamlit app
```
streamlit run dashboard.py
```
